#include<lhr.h>
using namespace std;
using namespace game;
stack <int> digit;//�����������ջ1
stack <char> symbol;//�����������ջ2
string a[7];
int color = 0;
void read_file() {
	ifstream in("use.txt");
	for (int i = 1; i <= 6; i++) in >> a[i];
	in >> color;
	in.close();
	return;
}
int level(char c) {
	if (c == '+' || c == '-') return 1;
	if (c == '*' || c == '/') return 2;
	if (c == '^') return 3;
	return 0;
}
void calculation() {
	int a = digit.top();
	digit.pop();
	int b = digit.top();
	digit.pop();
	char ch = symbol.top();
	symbol.pop();
	if (ch == '+') digit.push(a + b);
	else if (ch == '-') digit.push(b - a);
	else if (ch == '*') digit.push(a * b);
	else if (ch == '/') digit.push(b / a);
	else if (ch == '^') digit.push(pow(b, a));
	return;
}
void cal() {
	cout << "����һ����ʽ��";
	string str;
	cin >> str;
	int len = str.length();
	int x = 0;
	bool tag = false;
	for (int i = 0; i < len; i ++) {
		if (str[i] >= '0' && str[i] <= '9') {
			x = x * 10 + str[i] - '0';
			tag = true;
		} else {
			if (tag) {
				digit.push(x);
				tag = false;
				x = 0;
			}
			if (str[i] == '(') {
				symbol.push(str[i]);
				continue;
			}
			if (str[i] == ')') {
				while (symbol.top() != '(') calculation();
				symbol.pop();
				continue;
			}
			while (!symbol.empty() && level(symbol.top()) >= level(str[i])) calculation();
			symbol.push(str[i]);
		}
	}
	if (tag) digit.push(x);
	while (!symbol.empty()) calculation();
	cout << digit.top() << endl;
	system("pause");
	return;
}
int main() {
	read_file();
	if (color == 0) system("color f0");
	if (color == 1) system("color 07");
	if (color == 2) system("color e0");
	system(" mode con cols=50  lines=30 ");
	cal();
	return 0;
}
