#include<lhr.h>
#include<bits/stdc++.h>
using namespace std;
using namespace game;
string menu[1010];
int menul;
string a[7];
int color=0;
void read_file() {
	ifstream in("use.txt");
	for (int i = 1; i <= 6; i++) in >> a[i];
	in >> color;
	in.close();
}
void print_time() {
	time_t now = time(0);
	char* dt = ctime(&now);
	cout << dt;
}
void menuu() {
	system("dir  /s  /b >menu.txt");
	ifstream in("menu.txt");
	menul = 1;
	while (!in.eof()) {
		in >> menu[menul];
		menul++;
	}
	in.close();
}
void notepad() {
	map<int, string>m;
	while (true) {
		cls();
		p("\n   OI�ʼ�", 0);
		print_time();
		p("|------------------|", 0);
		p("|     1.��¼�ʼ�   |", 0);
		p("|------------------|", 0);
		p("|     2.�鿴��ʷ   |", 0);
		p("|------------------|", 0);
		p("|     3.ɾ���ʼ�   |", 0);
		p("|__________________|", 0);
		p("�����������", 0);
		char c = getch();
		switch (c) {
			case '1': {
				cls();
				cout << "������⣺";
				string title;
				cin >> title;
				ofstream out(title + ".txt");
				cout << "�����루������Ҫ���У����о�����һ��\ n������ @Ϊ��β����";
				string D;
				while (cin >> D) {
					if (D == "@") break;
					out << D << " ";
				}
				break;
			}
			case '2': {
				menuu();
				cls();
				int ii = 1;
				p("\n   OI�ʼ�", 0);
				print_time();
				for (int i = 1; i <= menul; i++) {
					if (menu[i].find("txt") != -1) {
						m[ii] = menu[i];
						cout << "|------------------|\n|     " << ii << ".";
						int t = menu[i].find("OIHelperV2.5");
						int jj = 0;
						for (int j = t + 13; j <= menu[i].length() - 5; j++) {
							cout << menu[i][j];
							jj++;
						}
						for (int j = 1; j <= 11 - jj; j++)cout << " ";
						cout << "|" << endl;
						ii++;
					}
				}
				p("|__________________|", 0);
				char C = getch();
				ifstream in(m[C - '0']);
				cls();
				while (!in.eof()) {
					string S;
					in >> S;
					cout << S << " ";
				}
				cout << endl;
				system("pause");
				break;
			}
			case '3': {
				{
					menuu();
					cls();
					int ii = 1;
					p("\n   ɾ���ʼ�", 0);
					print_time();
					for (int i = 1; i <= menul; i++) {
						if (menu[i].find("txt") != -1) {
							m[ii] = menu[i];
							cout << "|------------------|\n|     " << ii << ".";
							int t = menu[i].find("OIHelperV2.5");
							int jj = 0;
							for (int j = t + 13; j <= menu[i].length() - 5; j++) {
								cout << menu[i][j];
								jj++;
							}
							for (int j = 1; j <= 11 - jj; j++)cout << " ";
							cout << "|" << endl;
							ii++;
						}
					}
					p("|__________________|", 0);
					p("|tip:��Ҫɾϵͳ�ļ�|", 0);
					char C = getch();
					cls();
					p("��ȷ��Ҫɾ����(y/n)", 0);
					if (is_get('y') == true) {
						ofstream out(m[C - '0']);
						out.clear();
						out << "�ļ��ѱ�ɾ����";
						cout << "ɾ���ɹ���" << endl;
						system("pause");
					}
					break;
				}
			}
			default:
				return;

		}
	}
}
int main() {
	read_file();
	if (color == 0) system("color f0");
	if (color == 1) system("color 07");
	if (color == 2) system("color e0");
	system(" mode con cols=50  lines=30 ");
	notepad();
	return 0;
}
